/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {useQuery} from '@tanstack/react-query';
import {api} from 'modules/api';
import {RequestError, request} from 'modules/request';
import {ProcessInstance} from 'modules/types';
import {useCurrentUser} from './useCurrentUser';

type Data = ProcessInstance[];

function useProcessInstances() {
  const {data: currentUser} = useCurrentUser();
  const userId = currentUser?.userId;

  return useQuery<Data, RequestError>({
    queryKey: ['processInstances', userId],
    queryFn: async () => {
      const {response, error} = await request(
        api.searchProcessInstances({
          userId: userId!,
          pageSize: 50,
        }),
      );

      if (response !== null) {
        return response.json();
      }

      throw error ?? new Error('Failed to fetch process instances');
    },
    refetchInterval: 5000,
    enabled: userId !== undefined,
  });
}

export {useProcessInstances};
